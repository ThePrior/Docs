﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Meticulus.Dpp.Utils;
using Meticulus.Sharepoint.InternalResources;
using Meticulus.Sharepoint.Utils;
using Microsoft.SharePoint;

namespace ProcessApptSchedules
{
    /// <summary>
    /// Processes a CSV file of records and creates records in the Schedule list from them.
    /// </summary>
    class MainProcessApptSchedules
    {
        private static string _siteUrl;
        private static string _webServerRelativeUrl;
        private static string _docLibName;
        private static bool _stopOnError;
        private static bool _newRecordsOnly;
        private static bool _deleteOnSuccess;
        private static bool _deleteToRecycleBin;

        private static bool _verbose = false;

        private static string _patientIDQuery = "<Where><Eq><FieldRef Name='EMR_PatientID' /><Value Type='Text'>{0}</Value></Eq></Where>";
        private static string _locationQuery = "<Where><Eq><FieldRef Name='EMR_Location' /><Value Type='Text'>{0}</Value></Eq></Where>";
        private static string _providerQuery = "<Where><And><Eq><FieldRef Name='EMR_Provider' /><Value Type='Text'>{0}</Value></Eq><Eq><FieldRef Name='Location' /><Value Type='Lookup'>{1}</Value></Eq></And></Where>";


        private static string _apptIDQuery = "<Where><Eq><FieldRef Name='EMR_AppointmentID' /><Value Type='Text'>{0}</Value></Eq></Where>";
        private static string _CSVQuery = "<Where><Eq><FieldRef Name='EMR_Schedule_Processing_Status' /><Value Type='Choice'>New</Value></Eq></Where>";


        //TODO: May be use https://github.com/bbadjari/ccli 
        //TODO: This is a Library written in C# for use with CLI (command-line interface) applications. 
        //TODO: Provides command-line argument parsing and help screen printing.



        static int Main(string[] args)
        {
            int retVal = 0;
            try
            {
                //TODO: Use CLI Parser class
                if (!ParseArgs(args))
                {
                    return 1;
                }

                Process();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                retVal = 1;
            }
            finally
            {
                //Console.WriteLine("Hit [ENTER] to exit");
                //Console.ReadLine();
            }
            return retVal;
        }

        private static bool ParseArgs(string[] args)
        {
            try
            {
                if (args.Length != 8)
                {
                    Usage();
                    return false;
                }

                _siteUrl = args[0];
                _webServerRelativeUrl = args[1];
                _docLibName = args[2];
                _stopOnError = Boolean.Parse(args[3]);
                _newRecordsOnly = Boolean.Parse(args[4]);
                _deleteOnSuccess = Boolean.Parse(args[5]);
                _deleteToRecycleBin = Boolean.Parse(args[6]);
                _verbose = Boolean.Parse(args[7]);
            }

            catch (Exception ex)
            {
                LogMessage(ex.Message);
                Usage();
                return false;
            }

            return true;
        }

        private static void LogMessageVerbose(string message)
        {
            if (_verbose)
            {
                Console.WriteLine(message);
            }
        }
        private static void LogMessage(string message)
        {
            Console.WriteLine(message);
        }
        private static void Usage()
        {
            Console.WriteLine("ERROR - Usage: ProcessAppointmentSchedules.exe <siteCollectionUrl> <webServerRelativeUrl> <docLibName> <stopOnError> <newRecordsOnly> <deleteOnSuccess> <useRecycleBin> <verbose>");
            Console.WriteLine("Example:\n\nProcessAppointmentSchedules.exe http://internal.css.local/emr /emr/goshen \"Schedule Bulk Import\" false true true false true");
        }


        private static void Process()
        {
            using (SPSite site = new SPSite(_siteUrl))
            {
                using (SPWeb web = site.OpenWeb(_webServerRelativeUrl))
                {

                    //TODO: Don't hard-code
                    SPList scheduleList = ListWrapper.Get(web, "Schedule"); //List that holds schedule records, i.e. one record per appt

                    try
                    {
                        //We need to set the default content type so that the EMR_Print_SetA_Status etc. choice fields will
                        //be initialised to their default 'Not Set' values.
                        ListWrapper.SetDefaultContentType(scheduleList, Constants.EMR_BATCH_PRINTING_CONTENT_TYPE);

                        SPDocumentLibrary docLib = DocumentLibraryWrapper.Get(web, _docLibName);
                        if (!DocumentLibraryWrapper.ContainsContentType(web, docLib, Constants.EMR_SCHEDULE_PROCESSING_CONTENT_TYPE))
                        {
                            throw new AggregateException(string.Format("Document library {0} must contain {1} content type.",
                                docLib.Title, Constants.EMR_SCHEDULE_PROCESSING_CONTENT_TYPE));
                        }

                        SPListItemCollection csvRecords = GetScheduleCSVRecords(docLib);
                        Dictionary<int, SPListItem> idDictionary = new Dictionary<int, SPListItem>(csvRecords.Count);
                        List<int> itemsProcessedOK = new List<int>(csvRecords.Count);
                        List<int> itemsProcessedWithErrors = new List<int>(32);

                        LogMessage(string.Format("{0} items to be processed in list {1}", csvRecords.Count, docLib.Title));


                        ProcessItems(web, scheduleList, csvRecords, idDictionary, itemsProcessedOK, itemsProcessedWithErrors);

                        if (_deleteOnSuccess)
                        {
                            LogMessage(string.Format("Deleting {0} successfully processed records from {1}", itemsProcessedOK.Count, docLib.Title));
                            DeleteItems(web, docLib, idDictionary, itemsProcessedOK);
                        }

                        LogMessage(string.Format("{0} CSV files processed successfuly. {1} CSV files have errors. See 'Schedule Bulk Import' list for details of any errors. ", itemsProcessedOK.Count, itemsProcessedWithErrors.Count));
                    }
                    finally
                    {
                        ListWrapper.SetDefaultContentType(scheduleList, Constants.EMR_SCHEDULE_CONTENT_TYPE); 
                    }
                }
            }
        }

        private static void DeleteItems(SPWeb web, SPDocumentLibrary docLib, Dictionary<int, SPListItem> idDictionary, List<int> idList)
        {
            //TODO delete avoiding recylec bin
            if (_deleteToRecycleBin)
            {
                DeleteToRecycleBin(web, docLib, idDictionary, idList);

                //For technology to delete from recycle bin see Archiver.cs.
            }
            else
            {
                DeleteItems(docLib, idList);
            }

            docLib.Update();
        }

        private static void DeleteItems(SPDocumentLibrary docLib, List<int> idList)
        {
            foreach (int itemID in idList)
            {
                SPListItem listItem = docLib.GetItemById(itemID);
                if (listItem != null)
                {
                    LogMessageVerbose(string.Format("Deleting item {0}", listItem.DisplayName));
                    listItem.Delete();
                }
            }
        }

        private static void DeleteToRecycleBin(SPWeb web, SPDocumentLibrary docLib, Dictionary<int, SPListItem> idDictionary, List<int> idList)
        {
            string batchString = GenerateBatchDeleteXml(docLib, idDictionary, idList);

            //NOTE: This method of deleting items will move them to the recycle bin.
            string results = web.ProcessBatchData(batchString);
        }

        private static string GenerateBatchDeleteXml(SPDocumentLibrary docLib, Dictionary<int, SPListItem> idDictionary, List<int> idList)
        {
            StringBuilder sbDelete = new StringBuilder();
            sbDelete.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Batch>");

            string command = "<Method>" +
                                "<SetList Scope=\"Request\">" + docLib.ID + "</SetList>" +
                                "<SetVar Name=\"ID\">{0}</SetVar>" +                        //Note: ID is ignored if using owsfileref
                                "<SetVar Name=\"owsfileref\">{1}</SetVar>" +                //Note: FileRef is required when deleting items from a Document Library (but not for a list where it is a no-op)
                                "<SetVar Name=\"Cmd\">Delete</SetVar>" +
                            "</Method>";

            foreach (int id in idList)
            {
                SPListItem listItem = idDictionary[id];
                string fileRef = listItem["FileRef"].ToString();
                sbDelete.Append(string.Format(command, id.ToString(), fileRef));
            }
            sbDelete.Append("</Batch>");
            return sbDelete.ToString();
        }


        private static SPListItemCollection GetScheduleCSVRecords(SPDocumentLibrary docLib)
        {
            if (!_newRecordsOnly)
                return docLib.Items;

            SPQuery camlQuery = new SPQuery();

            camlQuery.Query = _CSVQuery;

            // includeFolders
            camlQuery.ViewAttributes = "Scope=\"Recursive\"";

            SPListItemCollection listItems = docLib.GetItems(camlQuery);
            return listItems;
        }

        private static void ProcessItems(SPWeb web, SPList scheduleList, SPListItemCollection csvRecords, Dictionary<int, SPListItem> idDictionary, List<int> itemsProcessedOK, List<int> itemsProcessedWithErrors)
        {
            /*
 * As Toni says when setting a date/time programatically you should use UTC.
 * The time zone that will be used for the display is set at the Web's level (regional setttings).
 * To convert between the web sites time zone to UTC you should get the webs time zone from the regional settings property and use the LocalTimeToUTC method
 * So something like:
 */
            SPTimeZone timeZone = web.RegionalSettings.TimeZone;
            CultureInfo cultureInfo = new CultureInfo((int)web.RegionalSettings.LocaleId);

            SPList patientsList = ListWrapper.Get(web, "Patients");
            SPList locationsList = ListWrapper.Get(web, "Locations");
            SPList providersList = ListWrapper.Get(web, "Providers");
            List<string> errorMessages = new List<string>();

            foreach (SPListItem item in csvRecords)
            {
                //Before processing each new CSV file, clear the error messages from the previous.
                errorMessages.Clear();

                try
                {
                    idDictionary.Add(item.ID, item);
                    SPFile file = item.File;
                    byte[] bytes = file.OpenBinary(SPOpenBinaryOptions.SkipVirusScan);

                    using (ScheduleFieldParser parser = new ScheduleFieldParser(bytes, cultureInfo))
                    {
                        while (!parser.EndOfData)
                        {
                            parser.ReadFields();

                            SPListItem patient = GetPatient(patientsList, parser.PatientID);
                            SPListItem location = GetLocation(locationsList, parser.Location);
                            SPListItem provider = GetProvider(providersList, parser.Provider, parser.Location);

                            if (patient == null)
                            {
                                string error = string.Format("No matching Patient found in Patients lists for Patient ID '{0}'. ", parser.PatientID);
                                LogMessageVerbose(error);
                                errorMessages.Add(error);
                            }
                            else if (location == null)
                            {
                                string error = string.Format("No matching Location found in Locations lists for Location '{0}'. ", parser.Location);
                                LogMessageVerbose(error);
                                errorMessages.Add(error);
                            }
                            else if (provider == null)
                            {
                                string error = string.Format("No matching Provider found in Providers lists for Provider '{0}' and Location '{1}'. ", parser.Provider, parser.Location);
                                LogMessageVerbose(error);
                                errorMessages.Add(error);
                            }
                            else
                            {
                                /*
                                Console.WriteLine(string.Format("PatientID: {0}, StartTime: {1}, Provider: {2}, Location: {3}",
                                    parser.PatientID, parser.StartTime, parser.Provider, parser.Location));
                                 */
                                AddOrUpdateAppointmentSchedule(scheduleList, parser, timeZone, patient, location, provider);
                            }
                        }
                    }

                    UpdateScheduleProcessingItem(item, null, errorMessages, itemsProcessedOK, itemsProcessedWithErrors);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                    UpdateScheduleProcessingItem(item, ex.Message, errorMessages, itemsProcessedOK, itemsProcessedWithErrors);

                    if (_stopOnError)
                        throw ex;
                }
            }
        }

        private static void AddOrUpdateAppointmentSchedule(SPList scheduleList, ScheduleFieldParser parser, SPTimeZone timeZone,
            SPListItem patient, SPListItem location, SPListItem provider)
        {
            SPListItem existingAppt = GetAppointment(scheduleList, parser.ApptID);
            if (existingAppt == null)
            {
                LogMessage(string.Format("Adding new appt. for Patient ID {0}. ", parser.PatientID));
                AddNewAppt(scheduleList, parser, timeZone, patient, location, provider);
            }
            else
            {
                LogMessageVerbose(string.Format("Updating matching Appointment ID {0} found in Schedule list. ", parser.ApptID));
                UpdateAppointment(existingAppt, parser, timeZone, patient, location, provider);
            }

        }

        private static void UpdateAppointment(SPListItem appointment, ScheduleFieldParser parser, SPTimeZone timeZone,
            SPListItem patient, SPListItem location, SPListItem provider)
        {
            appointment["Lookup_EMR_PatientID"] = patient.ID;

            appointment["EMR_Location_Lookup"] = location.ID;
            appointment["EMR_Provider_Lookup"] = provider.ID;


            //See comment in ListItemWrapper.SetDateTimeFieldValue() - about how SharePoint expects DateTime to be specified.
            //Essentially it appears that SharePoint expects the date time to be specified in the timezone of the current SharePoint web
            //It may well be that SharePoint then internally stores this in UTC.
            appointment["EMR_AppointmentDate"] = parser.StartTime;
            appointment.Update();
        }

        private static void AddNewAppt(SPList scheduleList, ScheduleFieldParser parser, SPTimeZone timeZone,
            SPListItem patient, SPListItem location, SPListItem provider)
        {
            SPListItem newAppointment = scheduleList.AddItem();
            newAppointment["EMR_AppointmentID"] = parser.ApptID;
            UpdateAppointment(newAppointment, parser, timeZone, patient, location, provider);
        }

        /// <summary>
        /// Updates the processed record in the document library holding the CSV files
        /// </summary>
        private static void UpdateScheduleProcessingItem(SPListItem item, string fatalError, List<string> errorMessages, List<int> itemsProcessedOK, List<int> itemsProcessedWithErrors)
        {
            string status;
            if (fatalError != null || errorMessages.Count > 0)
            {
                status = "Failed";
                itemsProcessedWithErrors.Add(item.ID);
            }
            else
            {
                status = "OK";
                itemsProcessedOK.Add(item.ID);
            }

            item["EMR_Schedule_Processing_Processed"] = 1;
            item["EMR_Schedule_Processing_Status"] = status;

            //Accessing multline text fields: see http://www.thesharepointblog.net/Lists/Posts/Post.aspx?ID=30 for useful summary
            StringBuilder message = new StringBuilder();

            if (fatalError != null)
            {
                message.AppendLine(fatalError);
            }

            foreach (string error in errorMessages)
            {
                message.AppendLine(error);
            }

            item["EMR_Schedule_Processing_Message"] = message.ToString();

            item.Update();
        }

        private static void UpdatePatient(SPListItem patient, ADTReader adtReader)
        {
            patient["EMR_PatientFirstName"] = adtReader.FirstName;
            patient["EMR_PatientLastName"] = adtReader.LastName;
            patient["EMR_PatientMiddleName"] = adtReader.MiddleName;
            patient["EMR_PatientGender"] = adtReader.GenderAsMaleOrFemale;
            patient["EMR_DOB"] = adtReader.DoB;

            patient.Update();
        }

        private static void AddAppointmentSchedule(SPListItemCollection patients, ADTReader adtReader)
        {
            SPListItem newPatient = patients.Add();
            newPatient["EMR_PatientID"] = adtReader.PatientID;
            UpdatePatient(newPatient, adtReader);
        }

        private static SPListItem GetPatient(SPList patientsList, string patientID)
        {
            LogMessageVerbose(string.Format("in GetPatient() - patientID = '{0}'", patientID));

            //Check if Patient with given ID already exists
            SPQuery camlQuery = new SPQuery();

            camlQuery.Query = string.Format(_patientIDQuery, patientID);

            // includeFolders
            camlQuery.ViewAttributes = "Scope=\"Recursive\"";

            SPListItemCollection listItems = patientsList.GetItems(camlQuery);

            SPListItem listItem = null;
            if (listItems.Count == 1)
            {
                listItem = listItems[0];
            }
            else if (listItems.Count > 1)
            {
                throw new ApplicationException(string.Format("Duplicate Patient IDs exist in Patients list. ID = {0}.", patientID));
            }

            return listItem;
        }

        private static SPListItem GetLocation(SPList locationsList, string location)
        {
            LogMessageVerbose(string.Format("in GetLocation() - location = '{0}'", location));

            //Check if Location name already exists
            SPQuery camlQuery = new SPQuery();

            camlQuery.Query = string.Format(_locationQuery, location);

            // includeFolders
            camlQuery.ViewAttributes = "Scope=\"Recursive\"";

            SPListItemCollection listItems = locationsList.GetItems(camlQuery);

            SPListItem listItem = null;
            if (listItems.Count == 1)
            {
                listItem = listItems[0];
            }
            else if (listItems.Count > 1)
            {
                throw new ApplicationException(string.Format("Duplicate locations '{0}' exist in Locations list.", location));
            }

            return listItem;
        }

        private static SPListItem GetProvider(SPList locationsList, string provider, string location)
        {
            LogMessageVerbose(string.Format("in GetProvider() - provider = '{0}', location = '{1}'", provider, location));

            //Check if Provider name with matching Location already exists
            SPQuery camlQuery = new SPQuery();

            camlQuery.Query = string.Format(_providerQuery, provider, location);

            // includeFolders
            camlQuery.ViewAttributes = "Scope=\"Recursive\"";

            SPListItemCollection listItems = locationsList.GetItems(camlQuery);

            SPListItem listItem = null;
            if (listItems.Count == 1)
            {
                listItem = listItems[0];
            }
            else if (listItems.Count > 1)
            {
                throw new ApplicationException(string.Format("Duplicate providers '{0}' exists in Providers list in same location '{1}'.",
                    provider, location));
            }

            return listItem;
        }

        private static SPListItem GetAppointment(SPList scheduleList, string apptID)
        {
            //Check if Appointment with given ID already exists
            SPQuery camlQuery = new SPQuery();

            camlQuery.Query = string.Format(_apptIDQuery, apptID);

            // includeFolders
            camlQuery.ViewAttributes = "Scope=\"Recursive\"";

            SPListItemCollection listItems = scheduleList.GetItems(camlQuery);

            SPListItem listItem = null;
            if (listItems.Count == 1)
            {
                listItem = listItems[0];
            }
            else if (listItems.Count > 1)
            {
                throw new ApplicationException(string.Format("Duplicate Appointment IDs exist in Schedule list. ID = {0}.", apptID));
            }

            return listItem;
        }

    }
}