Add-Type -assembly System.Security
Add-PSSnapin Microsoft.SharePoint.PowerShell 

$WebServerRelativeUrl=$args[0] # e.g. http://internal.penad.wrshealth.com/emr or http://internal.css.local/emr
$TopLevelFolder=$args[1] #Typically C:\ApptSchedules, subfolders must match to Practice subsites in SharePoint
$promptForCredentials=[System.Convert]::ToBoolean($args[2])

$user = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name

$Credential = $null

$path = ".\password.bin"


$CurrentDir = Resolve-Path .
$logfile=$CurrentDir.Path + "\ApptScheduleBulkImport.log"
Start-Transcript $logfile

# Retrieve and decrypt password
if (!$promptForCredentials){
	if (-not (Test-Path $path)) { 
		$message = "password file " + $path + " not found, run EncryptPassword first"
		echo $message
		exit 1 
	}

	$password = Get-Content $path | ConvertTo-SecureString 
	if ([string]::IsNullOrEmpty($password)){
		exit 
	}

	$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $user, $password
} else {
	$Credential = Get-Credential -Credential $user
}


function Import-Files([string] $Source, [string] $Dest) {

$Drive = "X"
if (Get-PSDrive -Name $Drive -ErrorAction SilentlyContinue) { Remove-PSDrive -Name $Drive -Scope Global | Out-Null }

# create using credentials
New-PSDrive -Name $Drive -PSProvider FileSystem -Root $Dest -Credential $Credential

# call from a separate function
#(Get-PSDrive -Name $Drive).root

#Get-PSDrive -PSProvider FileSystem

#TODO: - SHOULD BE MOVE
#$Source

#Move-Item $Source\* X: -Force
Copy-Item $Source\* X:

}

function ProcessApptSchedules([string] $WebServerRelativeUrl, [string] $DocLibName, [string] $SourceLib) {
# ProcessApptSchedules.exe <siteCollectionUrl> <webServerRelativeUrl> <docLibName> <stopOnError> <newRecordsOnly> <deleteOnSuccess> <useRecycleBin> <verbose>

#ProcessApptSchedules.exe http://internal.css.local/emr /emr/goshen "Schedule Bulk Import" false false true true true

cd $CurrentDir

. ./ProcessApptSchedules.exe $WebServerRelativeUrl $DocLibName $SourceLib false false true false false

}

function Set-CustomPrintStatus([string] $siteUrl, [string] $webURL, [string] $PracticeName) {

#Sets status of EMR_Print_SetA_Status etc. fields to Queued depending on Practice
if ($PracticeName -eq "Goshen"){
		Write-Host "Set-CustomPrintStatus for Practice $PracticeName in $siteUrl $webURL"
		
		#List to update
		$listName = "Schedule"
		
		try 
		{ 
			$spSite=Get-SPSite -Identity $siteUrl 
			$spwWeb=$spSite.OpenWeb($webURL)
			$spList = $spwWeb.Lists.TryGetList($listName)  
			if ($spList)  
			{  
				#Note: Don't attempt to reuse the same SPQuery object just by changing the Query string - doesn't seem to work.

				$spqQuery = New-Object Microsoft.SharePoint.SPQuery 
				
				$spqQuery.Query =  
					"<Where><Eq><FieldRef Name='EMR_Print_SetA_Status' /><Value Type='Choice'>Not Set</Value></Eq></Where>" 
					
				$spListItems = $spList.GetItems($spqQuery) 

				Write-Host "Updating " $spListItems.Count " items found with status 'Not Set' "
 
				foreach ($spListItem in $spListItems) 
				{ 
					$spListItem["EMR_Print_SetA_Status"] = "Queued"
					$spListItem.update()
				} 				
			}   
			   
			$spSite.Dispose() 
		} 
		catch [System.Exception] 
		{ 
			Write-Host -f red $_.Exception.ToString() 
		} 
	}

}

cd $TopLevelFolder
Get-ChildItem -Directory | foreach {
    $Dest =  $WebServerRelativeUrl -replace "http://", "\\"
    $Dest = $Dest + "\" + $_ + "\Schedule Bulk Import"
	$Source = $TopLevelFolder + "/" + $_

	Write-Host Import-Files "$Source $Dest"
	Import-Files $Source $Dest
	
	$DocLibName = "/emr/" + $_
	$SourceLib = "Schedule Bulk Import"

	Write-Host ProcessApptSchedules "$WebServerRelativeUrl $DocLibName $SourceLib"
	ProcessApptSchedules $WebServerRelativeUrl $DocLibName $SourceLib
	
	Set-CustomPrintStatus $WebServerRelativeUrl $DocLibName $_
	Write-Host "`n"
	}

Write-Host "Done..." -ForegroundColor Magenta
Stop-Transcript 