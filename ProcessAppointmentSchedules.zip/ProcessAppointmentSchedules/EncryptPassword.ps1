﻿# See http://stackoverflow.com/questions/1530733/powershell-how-to-map-a-network-drive-with-a-different-username-password
# Stick password into DPAPI storage once - accessible only by current user
Add-Type -assembly System.Security
$user = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$Credential = Get-Credential -Credential $user
$password = $credential.Password 
$credential.Password | ConvertFrom-SecureString | Set-Content .\password.bin 

#$password = Get-Content .\password.bin | ConvertTo-SecureString 
